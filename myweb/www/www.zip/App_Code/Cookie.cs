﻿

using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for Cookie
/// </summary>
public class Cookie
{
    
    public static string ComplanyId = "gongsi_id";
    public static string UserId = "userPass";
    public static string UserIdcookie = "cookid";

    public static string UserNameCookieName = "userName";
    public static string UserNameCookieNicheng = "ddd";
    public static string ShangchengUserID = "userID";
}
