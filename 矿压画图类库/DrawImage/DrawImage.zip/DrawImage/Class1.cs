﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DrawImage
{
    public class Class1
    {
        
    }
}
