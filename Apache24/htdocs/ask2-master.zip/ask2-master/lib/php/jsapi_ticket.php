<?php exit();?>
{"jsapi_ticket":"","expire_time":0}
