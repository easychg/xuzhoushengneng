<?php 

$tphtml = array(

	'answer/append' => '追问',
	'answer/ajaxviewcomment' => '追问',
'answer/ddcomment' => '追问',
'answer/deletecomment' => '追问',
	'answer/deletecomment' => '追问',
'answer/ajaxaddsupport' => '追问',


);

?>