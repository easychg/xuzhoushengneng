<?php 
define('WB_AKEY',  '1515056452');
define('WB_SKEY',  '86ee4c6e626d57fe2ad7d38709134352');
define('WB_CALLBACK_URL',  'http://www.ask2.cn/plugin/sinalogin/callback.php');
