<?php die('forbidden'); ?>
{
"appid":"101316662",
"appkey":"08aa77857aabfebc5b3dee241cf21f68",
"callback":"http://m.ask2.cn/plugin/wapqqlogin/callback.php",
"scope":"get_user_info",
"errorReport":"true",
"storageType":"file"
}