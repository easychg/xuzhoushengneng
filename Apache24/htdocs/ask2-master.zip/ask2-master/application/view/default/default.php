<?php 

$tphtml = array(

	'404.html' => '网站404页面',
	'activelist.html' => '用户列表页面',
	'addxinzhi.html' => '文章添加页面',
	'appendanswer.html' => '追加回答页面',
	'ask.html' => '提问页面',
			'category.html' => '分类列表页面',
			'catlist.html' => '文章分类页面',
			'doing.html' => '网站动态页面',
			'editanswer.html' => '编辑回答页面',
			'editimg.html' => '修改头像页面',
			'editquestion.html' => '修改问题页面',
			'editxinzhi.html' => '修改新知页面',
        'expert.html'=> '专家列表',
 'footer.html'=> '底部公共页面',
 'getpass.html'=> '忘记密码',
 'giftlist.html'=> '礼物列表',
'meta.html'=> 'Meta头部公共页面',
 'header.html'=> '头部公共页面',
 'help.html'=> '帮助页面',
 'index.html'=> '首页',
 'login.html'=> '登陆页面',
 'maketag.html'=> '自动生成标签页',
 'message.html'=> '私信页面',
 'myanswer.html'=> '我的回答页面',
 'myask.html'=> '我的提问页面',
 'mycategory.html'=> '我擅长的分类页面',
 'myfollower.html'=> '关注我的人页面',
 'myrecommend.html'=> '我的推荐页面',
 'myscore.html'=> '个人中心页面',
 'myset.html'=> '我的设置页面',
 'myxinzhi.html'=> '我的新知页面',
 'new.html'=> '最新问题页面',

 'note.html'=> '通知详情页',
 'notelist.html'=> '通知列表页面',
 'poplogin.html'=> '弹出登陆框模板页面',
 'profile.html'=> '修改个人资料页面',
 'register.html'=> '注册页面',
 'scorelist.html'=> '达人榜页面',
 'search.html'=> '搜索列表页',
 'sendmsg.html'=> '发私信',
 'solve.html'=> '问题想请页面',
 'space.html'=> '网友个人中心',
 'space_answer.html'=> '网友问题回答页面',
 'space_ask.html'=> '网友问题列表页面',
 'space_menu.html'=> '网友页面左侧模板页',
 'tag.html'=> '标签页面',
 'tip.html'=> '网站信息提示页面',
 'topic.html'=> '文章首页',
'topichot.html'=> '热文列表',
 'topicone.html'=> '文章详情页',
 'topictag.html'=> '文章标签页',
 'uppass.html'=> '修改个人密码',
 'user_menu.html'=> '个人中心左侧模板',

 'usercard.html'=> '鼠标滑到头像显示用户卡片页面',

 'userxinzhi.html'=> '用户个人发布的文章列表页面',
 'viewmessage.html'=> '查看私信详情'


);

?>