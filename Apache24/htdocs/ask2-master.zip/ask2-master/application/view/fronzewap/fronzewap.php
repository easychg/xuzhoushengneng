<?php 

$tphtml = array(


	
	

	'ask.html' => '提问页面',
			'category.html' => '分类列表页面',
			
		

	
		

 'footer.html'=> '底部公共页面',
 'getpass.html'=> '忘记密码',

 'header.html'=> '头部公共页面',

 'index.html'=> '首页',
 'login.html'=> '登陆页面',

 


 'myscore.html'=> '个人中心页面',






 'register.html'=> '注册页面',

 'search.html'=> '搜索列表页',
 'searchkey.html'=> '搜索输入框页',
 
 'solve.html'=> '已解决问题页面',
 'space.html'=> '网友个人中心',
 

 'tip.html'=> '网站信息提示页面',
 'topic.html'=> '文章首页',
 'topicone.html'=> '文章详情页',
'topictag.html'=> '文章标签列表'








);

?>