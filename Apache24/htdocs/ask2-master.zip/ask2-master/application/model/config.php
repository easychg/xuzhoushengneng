<?php 
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PW', 'zhengyingsence');
define('DB_NAME', 'sowenda');
define('DB_CHARSET', 'utf8');
define('DB_TABLEPRE', 'ask_');
define('DB_CONNECT', 0);
define('TIPASK_CHARSET', 'UTF-8');
define('TIPASK_VERSION', '2.5');
define('TIPASK_RELEASE', '20140526');
