<?php

!defined('IN_ASK2') && exit('Access Denied');

class articlecommentcontrol extends base {
   
    function __construct(& $get, & $post) {
        parent::__construct($get, $post);
        $this->load('articlecomment');
       
    }

 

   
  

   

  

}

?>
