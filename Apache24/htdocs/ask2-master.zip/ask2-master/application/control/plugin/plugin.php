<?php

!defined('IN_ASK2') && exit('Access Denied');

class plugin extends base {

    function plugin(& $get, & $post) {
        $this->base($get,$post);
        
    }

    function ondefault() {
      
         
    }

}

?>