<?php
!defined('IN_ASK2') && exit('Access Denied');
class redirectcontrol extends base {

    function redirectcontrol(& $get, & $post) {
        parent::__construct($get, $post);
       
    }
    
    function onchange() {
    	
    }
    
}