<?php
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>说明</title>
</head>
<body>
请选择左边的管理菜单
</body>
</html>